/* file : search.h
 * author : Tiane Zhu
 * date : Apr 5, 2017
 *
 * header file for search.cu
 */

#ifndef SEARCH_H
#define SEARCH_H

#include <stdio.h>
#include "../../gpu_utils/util.h"

//#define SEARCH_PRINT 1

typedef int number;
#define FMT "%d "

#endif
