# gpu parallel
Algorithm implementations

# 4_1_parallel_search
author : Tiane Zhu

this program is an implementation of the parallel search algorithm

	ALGORITHM 4.1 in 

"An Introduction to Parallel Algorithms" - by Joseph Jaja

	p146 - ISBN 9-789201-548563

# 4_2_ranking_a_sorted_sequence_in_another_sorted_sequence
author : Tiane Zhu

this program is an implementation of the ranking sorted sequences

	ALGORITHM 4.2 in 

"An Introduction to Parallel Algorithms" - by Joseph Jaja

	p150 - ISBN 9-789201-548563

# 4_4_pipelined_merge_sort
author : Tiane Zhu

this program is an implementation of the pipelined merge sort algorithm

	ALGORITHM 4.4 in 

"An Introduction to Parallel Algorithms" - by Joseph Jaja

	p163 - ISBN 9-789201-548563

# 4_5_bitonic_merge_sort
author : Tiane Zhu

this program is an implementation of the parallel search algorithm

	ALGORITHM 4.5 in 

"An Introduction to Parallel Algorithms" - by Joseph Jaja

	p178 - ISBN 9-789201-548563


# gpu utils
This is a repo created to make cuda Coding and Timing more efficient
